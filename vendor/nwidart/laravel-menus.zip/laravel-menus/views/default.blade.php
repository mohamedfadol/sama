<ul class="nav navbar-nav">
  @include('menus::menu')
</ul>
