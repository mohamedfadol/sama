<ul class="nav nav-pills  nav-justified">
  @include('menus::menu')
</ul>
