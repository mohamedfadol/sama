<ul class="nav navbar-nav navbar-right">
  @include('menus::menu')
</ul>
