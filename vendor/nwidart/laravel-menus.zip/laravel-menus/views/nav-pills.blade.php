<ul class="nav nav-pills">
  @include('menus::menu')
</ul>
