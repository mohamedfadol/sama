<ul class="nav nav-tabs">
  @include('menus::menu')
</ul>
