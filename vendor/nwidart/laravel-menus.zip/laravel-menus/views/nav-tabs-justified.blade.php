<ul class="nav nav-tabs nav-justified">
  @include('menus::menu')
</ul>
