<ul class="nav navbar-nav navbar-left">
  @include('menus::menu')
</ul>
