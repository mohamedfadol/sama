<ul class="nav nav-pills nav-stacked">
  @include('menus::menu')
</ul>
