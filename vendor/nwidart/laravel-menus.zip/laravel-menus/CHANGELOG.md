# Changelog

All Notable changes to `laravel-menus` will be documented in this file.

## Next

## 6.0.0 - 2020-11-11

### Added

- Laravel 8 support

## 5.0.0 - 2019-10-01

### Added

- laravel 6.0 support

## 4.0.0 - 2019-10-01

### Added

- laravel 5.8 support

## 3.0.0 - 2018-09-30

### Added

- laravel 5.7 support

## 2.0.0 - 2018-02-14

### Added

- Laravel 5.6 support

### Removed

- Php 5.6 and 7.0

## 1.0.0 - 2017-09-01

### Added

- Support laravel 5.5
- Dropping php 5.6 support

## 0.5.0 - 2017-09-01

### Added

- Added a Zurb Foundation menu presenter
- Added a AdminLTE menu presenter
- More tests
- Changelog file
